# **GROCERY**
![screenshot](https://user-images.githubusercontent.com/30049606/67609556-3fb15800-f742-11e9-816f-2fbd88091b7c.png)

**GROCERY** is a recommendation app for predicting what a user will buy on their next
grocery trip based on their previous purchases. It uses tf-idf to compare a user's
orders to that of other users, and recommends items based on their similarity.

[Check out the website](https://grocery-paulo.herokuapp.com/)
